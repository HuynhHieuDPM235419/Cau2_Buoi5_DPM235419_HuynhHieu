#include <WiFi.h>
#include <PubSubClient.h> // Thư viện MQTT Client (Chương 5)[cite: 494, 495]

// Cấu hình WiFi Wokwi
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL 6

// Cấu hình MQTT Broker công cộng của HiveMQ (Trang 213, 215)[cite: 492, 494, 495]
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* mqtt_topic = "agu/iot/dongho/time";

WiFiClient espClient;
PubSubClient client(espClient);

// Chân nối 3 biến trở (Giờ, Phút, Giây)
const int POT_HOUR = 34;
const int POT_MIN  = 35;
const int POT_SEC  = 32;

void reconnect() {
  while (!client.connected()) {
    Serial.print("Dang ket noi MQTT HiveMQ...");
    String clientId = "ESP32-Publisher-" + String(random(0xffff), HEX);
    if (client.connect(clientId.c_str())) {
      Serial.println(" Thanh cong!");
    } else {
      Serial.print(" That bai, rc=");
      Serial.print(client.state());
      Serial.println(" Thu lại sau 2 giay...");
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL);
  Serial.print("Dang ket noi WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }
  Serial.println(" Da ket noi WiFi!");

  // Thiết lập MQTT Server (Trang 215)[cite: 494, 495]
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // Đọc giá trị từ 3 biến trở và quy đổi thời gian
  int gio  = map(analogRead(POT_HOUR), 0, 4095, 0, 23);
  int phut = map(analogRead(POT_MIN),  0, 4095, 0, 59);
  int giay = map(analogRead(POT_SEC),  0, 4095, 0, 59);

  // Đóng gói chuỗi thông điệp dạng "HH:MM:SS"
  char payload[16];
  snprintf(payload, sizeof(payload), "%02d:%02d:%02d", gio, phut, giay);

  // Gửi dữ liệu lên Broker bằng hàm publish() (Trang 215)[cite: 494, 495]
  client.publish(mqtt_topic, payload);
  Serial.print("Da Publish len Topic [");
  Serial.print(mqtt_topic);
  Serial.print("]: ");
  Serial.println(payload);

  delay(1000); // Gửi dữ liệu mỗi 1 giây
}